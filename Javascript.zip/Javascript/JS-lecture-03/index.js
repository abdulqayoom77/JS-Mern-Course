var num = 10;

// decrement operator
num--;
// increment operator
num++;

// console.log(num);


// Math expressions:
// Eliminating ambiguity

var totalCost =  1 * 9 * (10 /(8 +9) * 10);
// console.log(totalCost)



// var welcomeMsg = "Welcome to our Website, "
// var finalMsg = welcomeMsg + userName
// alert(finalMsg)
 

// ******************** Prompts **************************** 

// var balance  = Number(prompt('Please Enter Your bank balance'))
// var totalBalance = balance + 100
// console.log(totalBalance)




// ******************** If Statements **************************** 

// var age = Number(prompt("Please Enter your age"));

// if(age <= 18){
    //     alert('You are allowed')
// }

// else{
//     alert("Aap abhi bache ho")
// }


    // ******************** Data types and comparison operators **************************** 
// var boolData = typeof(12)
// console.log(boolData)

var age = "12"
var age2 = 12

if(age !== age2){
    alert("True")
}else{
    alert("False")
}