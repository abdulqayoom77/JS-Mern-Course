// alerts and variables for strings ch01 and ch02


// var a = "Abdul";
// var umr = 21;
// var abc = "kuch to hai"

// alert(a + umr)

// a = "Abdul Qayoom"
// umr = 22

// alert(a + umr)



// Variables for numbers ch03

var weight = 65;
// alert(weight + 25)

// var originalNumber = 50
// var newNumber = weight
// alert(newNumber)


var originalNumber = "53";
var newNum = 5 - originalNumber 
// alert(newNum)

alert("safysdfh")


// var full name = "abdul"
var alertCount = 1234


var Name = 'Abdul'
var name = 'Abdul'