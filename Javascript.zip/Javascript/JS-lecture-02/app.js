// alert("Mike test 123")

var num1 = 1000;
var num2 = 100;
var result = num1 / num2;

console.log(result)
