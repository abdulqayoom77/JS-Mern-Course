// var animals = ["dog", "cat", "fly", "bug", "ox"]
// animals.splice(0, 0, "duck", 'ant')
// var insects = animals.slice(2,4)
// console.log(insects)
// console.log(animals)
// for(var i=100; i >= 0; i-- ){
//     console.log(i)
// }
var cleanestCities = [
  "Cheyenne",
  "Santa Fe",
  "Tucson",
  "Great Falls",
  "Honolulu",
  "karachi",
];
for (var i = 0; i <= cleanestCities.length; i++) {
  console.log(cleanestCities[i]);
}