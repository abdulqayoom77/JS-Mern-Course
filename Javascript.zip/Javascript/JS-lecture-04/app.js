// var marks = Number(prompt("Enter marks"));
// var attendance = Number(prompt("Enter your attendance"))

// if (marks >= 50) {
//   // First level condition: passed the exam
//   if (attendance >= 75) {
//     console.log("Passed with good attendance");
//   } else {
//     console.log("Passed but low attendance");
//   }
// } else {
//   // Student failed the exam
//   if (attendance >= 75) {
//     console.log("Failed, but attendance was good");
//   } else {
//     console.log("Failed with low attendance");
//   }
// }

var cities = ["karachi", "London", " Islamabad"];
// console.log(cities[0], cities[1], cities[2]);


// var arr = ["kacrachi", 123, false, ['a', 'b']]

// cities[3] = "lahore"

// console.log(cities[0], cities[1], cities[3]);

// var pets = [];
// // pets[0] = "dog";
// // pets[1] = "cat";
// // pets[2] = "bird";
// pets[3] = "lizard";
// pets[6] = "snake";
// console.log(pets[3])

var cities = ["karachi", "London", "Islamabad", 'rawalpindi', 'larkana'];
// cities.pop()
// cities.push('rawalpindi', 'larkana')
// cities.shift()

cities.unshift("peshawar", "quetta", "skardu")
console.log(cities)