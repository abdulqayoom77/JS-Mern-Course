var fruits = ["apple", "mango", "orange", "banana", "grapes"];

// console.log(fruits[0])
// console.log(fruits[1])
// console.log(fruits[2])
// console.log(fruits[3])
// console.log(fruits[4])

// for (var i = 0; i < fruits.length; i++) {
//   console.log(fruits[i]);
// }

// var cityToCheck = prompt("Enter your city name");
var cleanestCities = ["karachi", "islamabad", "lahore", "quetta", "peshawar"];

/*if (cityToCheck === cleanestCities[0]) {
  alert("It's one of the cleanest cities");
} else if (cityToCheck === cleanestCities[1]) {
  alert("It's one of the cleanest cities");
} else if (cityToCheck === cleanestCities[2]) {
  alert("It's one of the cleanest cities");
} else if (cityToCheck === cleanestCities[3]) {
  alert("It's one of the cleanest cities");
} else if (cityToCheck === cleanestCities[4]) {
  alert("It's one of the cleanest cities");
} else {
  alert("It's not on the list");
}*/

// for (var i = 0; i < cleanestCities.length; i++) {
//   if (cityToCheck === cleanestCities[i]) {
//     alert("it's on the list of cleanest cities");
//   }
// }

// for (var i = 0; i <= 4; i++) {
//   if (cityToCheck === cleanestCities[i]) {
//     alert("It's one of the cleanest cities");
//   }
// }

// var matchFound = false;
// for (var i = 0; i <= 4; i++) {
//   if (cityToCheck === cleanestCities[i]) {
//     matchFound = true;
//     alert("It's one of the cleanest cities");
//     break;
//   }

// }

// if (matchFound === false){
//     alert("not found")
// }

// Beginner level exercise number one

// even number


// for (var i=1 ; i <= 100; i++){
//     console.log(i * i)
// }

// summ 

var sum = 0;
for ( var i=0 ; i<=100 ; i++){
    sum += i
}
console.log(sum)

// var num = "abdul qayoom"
// num += 1
// console.log(num)